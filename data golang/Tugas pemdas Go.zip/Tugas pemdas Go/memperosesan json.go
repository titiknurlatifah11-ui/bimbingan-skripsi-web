// package main

// import (
// 	"encoding/json"
// 	"fmt"
// )

// func main() {
// 	jsonString := `{"nama": "Gilang", "usia": 19, "jurusan": "Rekam medis"}`
// 	var data map[string]interface{}
// 	json.Unmarshal([]byte(jsonString), &data)
// 	fmt.Println("Data Map:", data)
// }
