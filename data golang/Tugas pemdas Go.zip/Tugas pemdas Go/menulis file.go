// package main

// import (
// 	"fmt"
// 	"io/ioutil"
// )

// func main() {
// 	data := []byte("Halo, ini adalah teks yang ditulis ke file.")
// 	err := ioutil.WriteFile("output.txt", data, 0644)
// 	if err != nil {
// 		fmt.Println("Error:", err)
// 		return
// 	}
// 	fmt.Println("Berhasil menulis ke file.")
// }
