// package main

// import (
// 	"fmt"
// 	"os"
// )

// func main() {
// 	_, err := os.Open("non_existent_file.txt")
// 	if err != nil {
// 		fmt.Println("File tidak ditemukan:", err)
// 		return
// 	}
// 	fmt.Println("File ditemukan")
// }
